This is a super simple 3rd person controller for Godot 4.
If you want something more complex, I recommend looking up  selgesel/godot3-third-person-controller

It functions by rotating the player character to be equal to the rotation of the camera, 
when the player moves.
The rotation is controlled by a lerp function.


LICENSE: MIT
